"""Make a Windows .ico in any theme color.
Usage:  python make_theme_icon.py "#8B5CF6" my_theme.ico
Needs:  pip install pillow numpy
"""
import sys, colorsys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
SRC_HUE = 178.0  # hue of the original teal artwork
SIZES = [16, 20, 24, 32, 40, 48, 64, 96, 128, 256]

def hue_shift(img, target_hue, sat_scale=1.0):
    a = np.asarray(img.convert("RGB")).astype(np.float32) / 255.0
    mx, mn = a.max(2), a.min(2); d = mx - mn
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    h = np.zeros_like(mx)
    m = d > 1e-6
    rc = m & (mx == r); gc = m & (mx == g) & ~rc; bc = m & ~rc & ~gc
    h[rc] = ((g - b)[rc] / d[rc]) % 6
    h[gc] = (b - r)[gc] / d[gc] + 2
    h[bc] = (r - g)[bc] / d[bc] + 4
    h = (h * 60 + (target_hue - SRC_HUE)) % 360
    s = np.where(mx > 0, d / np.maximum(mx, 1e-6), 0) * sat_scale
    s = np.clip(s, 0, 1); v = mx
    c = v * s; x = c * (1 - np.abs((h / 60) % 2 - 1)); mm = v - c
    z = np.zeros_like(c)
    sec = (h // 60).astype(int) % 6
    R = np.choose(sec, [c, x, z, z, x, c]); G = np.choose(sec, [x, c, c, x, z, z]); B = np.choose(sec, [z, z, x, c, c, x])
    out = np.stack([R + mm, G + mm, B + mm], 2)
    return Image.fromarray((np.clip(out, 0, 1) * 255 + 0.5).astype(np.uint8))

def rounded_mask(size, radius_frac=250/1024):
    k = 4; S = size * k
    m = Image.new("L", (S, S), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, S - 1, S - 1), radius=int(S * radius_frac), fill=255)
    return m.resize((size, size), Image.LANCZOS)

def build(master_path, hex_color, out_ico):
    rgb = Image.open(master_path).convert("RGB")
    hx = hex_color.lstrip("#"); r, g, b = (int(hx[i:i+2], 16) / 255 for i in (0, 2, 4))
    hue = colorsys.rgb_to_hsv(r, g, b)[0] * 360
    themed = hue_shift(rgb, hue)
    frames = []
    for s in SIZES:
        f = themed.resize((s, s), Image.LANCZOS)
        if s <= 256:
            f = f.filter(ImageFilter.UnsharpMask(radius=0.7 if s > 48 else 0.5, percent=45 if s > 96 else 90, threshold=1))
        f = f.convert("RGBA"); f.putalpha(rounded_mask(s)); frames.append(f)
    frames[-1].save(out_ico, format="ICO", sizes=[(s, s) for s in SIZES], append_images=frames[:-1])

if __name__ == "__main__":
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    build(os.path.join(here, "master_512_teal.png"), sys.argv[1], sys.argv[2])
