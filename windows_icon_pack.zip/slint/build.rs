fn main() {
    slint_build::compile("ui/app.slint").unwrap();

    // Embed the .ico in the .exe (Explorer, Start menu, pinned shortcuts).
    // Check the *target* OS, not cfg!(windows), so cross-compiling works too.
    if std::env::var("CARGO_CFG_TARGET_OS").unwrap() == "windows" {
        let mut res = winresource::WindowsResource::new();
        res.set_icon("assets/icon_teal.ico"); // default-theme icon
        res.compile().unwrap();
    }
}
