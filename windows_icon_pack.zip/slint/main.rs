slint::include_modules!();

fn main() -> Result<(), slint::PlatformError> {
    let ui = MainWindow::new()?;

    // Call this whenever the user changes theme:
    ui.set_theme_index(1); // e.g. blue

    ui.run()
}
